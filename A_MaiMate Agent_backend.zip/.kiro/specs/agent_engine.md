# \# Spec: Agent \& Action Engine (A 包)

# 

# \## 1. Goal

# 建立基於 AWS Bedrock (Claude 3.5 Sonnet / Claude 3 Haiku) Converse API 的 Agent 核心，實現對話管理、Tool Dispatching、Guardrails 過濾、Prepare/Execute 安全二階段分離，以及符合 §3 Schema 的方案計算與 Profile 引擎。

# 

# \## 2. Constraints \& Environment

# \- Runtime: Python 3.10+ / 3.11

# \- SDK: boto3 (Converse API)

# \- AWS Region: us-east-1

# \- Primary Model: anthropic.claude-3-5-sonnet-20240620-v1:0

# \- Fast Model: anthropic.claude-3-haiku-20240307-v1:0

# \- Folder Boundary: backend/agent/

# 

# \## 3. Core Modules \& Tasks

# \- \[ ] Task 1: Bedrock Client (Converse API Converse Loop)

# \- \[ ] Task 2: Tools Dispatch \& Prepare/Execute Separation

# \- \[ ] Task 3: Haiku/Sonnet Routing \& System Prompt Caching

# \- \[ ] Task 4: Profile Engine (User Badges)

# \- \[ ] Task 5: Three-Strategy Calculator (Card Schema)

# \- \[ ] Task 6: B/D Integration (Knowledge Registration, Guardrails, Audit Points)

# 

# \## 4. Definition of Done (DoD)

# \- 所有單元測試在 backend/tests/ 通過率 100%

# \- 不依賴真實網路情況下可用 Mock Data 通過 Prepare/Execute 驗證

# \- 輸出格式嚴格符合全專案 JSON Schema 規範


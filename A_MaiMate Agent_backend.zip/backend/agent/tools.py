import logging
from typing import Any

# 建立專屬 Logger 方便 C 包在決策面板抓取軌跡
logger = logging.getLogger("ToolsDispatcher")

class AgentTools:
    """
    Agent 工具與安全護欄派發中心
    實作 Prepare (驗證/預覽) 與 Execute (執行) 二階段分離
    """
    
    @staticmethod
    def place_order_prepare(market: str, side: str, price: float, volume: float) -> dict[str, Any]:
        """
        【階段一：Prepare】攔截 AI 下單意圖，進行本機風險檢查。
        回傳給前端 (C 包) 渲染 Confirm 卡片用的資料，保證不消耗真實交易額度。
        """
        logger.info(f"🛡️ [Prepare] 攔截下單意圖: {side} {volume} 單位 {market} @ {price}")
        
        # 1. 基礎防呆護欄
        if price <= 0 or volume <= 0:
            return {"status": "BLOCKED", "reason": "價格或數量必須大於 0"}
        
        # 2. 金額上限護欄 (防止 AI 幻覺亂下單)
        estimated_cost = price * volume
        if estimated_cost > 100000:
            return {"status": "BLOCKED", "reason": "危險！超出單筆十萬台幣安全上限。"}

        # 3. 封裝前端 Confirm 卡片所需 Schema
        return {
            "status": "REQUIRES_CONFIRMATION",
            "action_summary": f"準備以單價 {price} 購買 {volume} 單位 {market}",
            "estimated_cost": estimated_cost,
            "payload_hash": "mock_hash_for_execute_888" # 產生一次性簽章交給前端
        }

    @staticmethod
    def place_order_execute(payload_hash: str) -> dict[str, Any]:
        """
        【階段二：Execute】用戶確認後，真正執行下單。
        (此處預留給 D 包串接真實 MAX API)
        """
        logger.info(f"🚀 [Execute] 用戶已確認，準備真正送出訂單 (Hash: {payload_hash})")
        
        if payload_hash != "mock_hash_for_execute_888":
            return {"status": "FAILED", "reason": "無效或過期的執行簽章"}
        
        return {
            "status": "SUCCESS",
            "order_id": "MAX_ORD_123456789",
            "message": "下單成功！"
        }
from typing import Any

class StrategyCalculator:
    """
    三方案計算機 (#11)
    嚴格輸出符合 §3 Scenarios Schema 的 JSON 格式，供 C 包渲染卡片
    """
    @staticmethod
    def generate_three_plans(budget_twd: float, current_market_price: float) -> dict[str, Any]:
        if budget_twd <= 0 or current_market_price <= 0:
            raise ValueError("預算與市場價格必須大於 0")

        # 計算最大可買數量 (精確到小數點後 4 位)
        max_volume = round(budget_twd / current_market_price, 4)

        return {
            "status": "SUCCESS",
            "market_price": current_market_price,
            "scenarios": [
                {
                    "plan_name": "保守方案 (30%)",
                    "action": "BUY",
                    "volume": round(max_volume * 0.3, 4),
                    "estimated_cost": round(budget_twd * 0.3, 2),
                    "description": "保留多數現金，適合觀望市場波動。"
                },
                {
                    "plan_name": "穩健方案 (60%)",
                    "action": "BUY",
                    "volume": round(max_volume * 0.6, 4),
                    "estimated_cost": round(budget_twd * 0.6, 2),
                    "description": "攻守兼備，參與市場漲幅同時控制風險。"
                },
                {
                    "plan_name": "積極方案 (100%)",
                    "action": "BUY",
                    "volume": max_volume,
                    "estimated_cost": budget_twd,
                    "description": "資金全數投入，追求最大利潤。"
                }
            ]
        }
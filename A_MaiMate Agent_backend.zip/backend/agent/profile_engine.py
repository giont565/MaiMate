class ProfileEngine:
    """
    Profile 引擎 (#10)
    負責分析用戶背景，產出供 C 包渲染的「用戶徽章 UI」
    """
    @staticmethod
    def generate_badges(age: int, investment_experience_years: int, risk_tolerance: str) -> list[str]:
        badges = []
        
        # 根據年齡與經驗給予基礎徽章
        if investment_experience_years >= 5:
            badges.append("👑 市場老手")
        else:
            badges.append("🌱 投資新手")
            
        # 根據風險承受度給予策略徽章
        if risk_tolerance.upper() == "HIGH":
            badges.append("🔥 積極進取")
        elif risk_tolerance.upper() == "LOW":
            badges.append("🛡️ 穩健防守")
        else:
            badges.append("⚖️ 平衡配置")
            
        return badges
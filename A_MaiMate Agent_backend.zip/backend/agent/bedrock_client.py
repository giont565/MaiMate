import logging
import boto3
import re
from typing import Any, List, Dict, Tuple, Optional

# 設定 Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - [%(levelname)s] - %(message)s')
logger = logging.getLogger("BedrockClient_PRO")

class BedrockAgentClient:
    """
    AWS Bedrock Converse API 封裝客戶端 (PRO 延伸思考版)
    """
    def __init__(self, region_name: str = "us-east-1"):
        self.region_name = region_name
        self.model_sonnet = "anthropic.claude-3-5-sonnet-20240620-v1:0"
        self.model_haiku = "anthropic.claude-3-haiku-20240307-v1:0"
        
        self.client = boto3.client(
            service_name="bedrock-runtime",
            region_name=self.region_name
        )

    def converse_with_thinking(
        self, 
        messages: List[Dict[str, Any]], 
        use_fast_model: bool = False,
        tools: Optional[List[Dict[str, Any]]] = None
    ) -> Tuple[str, str, Dict[str, Any]]:
        """
        核心對話函式，強制模型進行 <thinking> 延伸思考。
        回傳值: (思考軌跡, 最終回覆, 原始 API 回應物件)
        """
        model_id = self.model_haiku if use_fast_model else self.model_sonnet
        
        system_prompt = (
            "你是一個專業的 MAX 交易所 AI 投資特助。"
            "在給出最終答案或呼叫任何工具之前，你必須先進行『邏輯推理與延伸思考』。"
            "請將你的思考過程嚴格包裝在 <thinking> 與 </thinking> 標籤中，不對用戶隱藏你的分析依據。"
            "思考結束後，在標籤外部給出你要對用戶說的話或執行的動作。"
        )

        kwargs: Dict[str, Any] = {
            "modelId": model_id,
            "messages": messages,
            "system": [{"text": system_prompt}],
            "inferenceConfig": {
                "maxTokens": 2048, 
                "temperature": 0.2, 
                "topP": 0.9
            }
        }
        
        if tools:
            kwargs["toolConfig"] = {"tools": tools}

        try:
            logger.info(f"發送請求至 [{model_id}] (啟動 PRO 延伸思考引擎)...")
            response = self.client.converse(**kwargs)
            
            content_blocks = response.get("output", {}).get("message", {}).get("content", [])
            raw_text = next((item["text"] for item in content_blocks if "text" in item), "")
            
            thinking_match = re.search(r"<thinking>(.*?)</thinking>", raw_text, re.DOTALL)
            thinking_process = thinking_match.group(1).strip() if thinking_match else "無延伸思考軌跡。"
            
            final_reply = re.sub(r"<thinking>.*?</thinking>", "", raw_text, flags=re.DOTALL).strip()
            
            return thinking_process, final_reply, response
            
        except Exception as e:
            logger.error(f"Bedrock 呼叫失敗: {str(e)}")
            raise e
import logging
from typing import Any
from backend.agent.bedrock_client import BedrockAgentClient
from backend.agent.tools import AgentTools
from backend.agent.profile_engine import ProfileEngine
from backend.agent.strategy_calculator import StrategyCalculator

logger = logging.getLogger("MaiMateAgent")

class MaiMateAgent:
    """
    A 包最終交付物：MaiMate 核心大腦 (Facade)
    將底層的所有模組 (Bedrock 通訊、安全護欄、徽章演算、方案計算) 統一封裝
    """
    def __init__(self):
        # 初始化 LLM 客戶端
        self.llm_client = BedrockAgentClient()

    def analyze_user_and_propose_strategy(
        self, age: int, exp_years: int, risk: str, budget: float, price: float
    ) -> dict[str, Any]:
        """
        一鍵產出用戶專屬 Profile 與 三大投資策略卡片
        """
        logger.info("🧠 啟動大腦組裝：產出 Profile 與投資策略...")
        
        # 呼叫 Profile 引擎 (#10)
        badges = ProfileEngine.generate_badges(age, exp_years, risk)
        
        # 呼叫三方案計算機 (#11)
        strategy = StrategyCalculator.generate_three_plans(budget, price)

        return {
            "user_profile": {"badges": badges},
            "strategy_cards": strategy
        }

    def handle_trade_intent(self, market: str, side: str, price: float, volume: float) -> dict[str, Any]:
        """
        一鍵攔截並處理下單意圖，返回 Confirm 卡片資料
        """
        logger.info("🛡️ 啟動護欄：處理交易意圖...")
        return AgentTools.place_order_prepare(market, side, price, volume)

    def confirm_and_execute_trade(self, payload_hash: str) -> dict[str, Any]:
        """
        用戶點擊確認後，一鍵執行交易
        """
        return AgentTools.place_order_execute(payload_hash)
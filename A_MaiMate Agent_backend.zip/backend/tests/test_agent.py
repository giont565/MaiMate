import unittest
from unittest.mock import MagicMock, patch
from backend.agent.bedrock_client import BedrockAgentClient

class TestBedrockAgentPRO(unittest.TestCase):
    """A 包階段 1 單元測試：PRO 級延伸思考引擎解析驗證"""

    @patch('boto3.client')
    def test_converse_with_thinking_parsing(self, mock_boto_client):
        mock_bedrock = MagicMock()
        mock_boto_client.return_value = mock_bedrock
        
        mock_raw_response = (
            "<thinking>\n"
            "1. 用戶意圖：連線測試與狀態確認。\n"
            "2. 決策：需要簡短回應確認狀態。\n"
            "</thinking>\n"
            "系統已上線！『第五名』團隊您好。"
        )
        
        mock_response = {
            "output": {"message": {"content": [{"text": mock_raw_response}]}},
            "usage": {"inputTokens": 50, "outputTokens": 80, "totalTokens": 130}
        }
        mock_bedrock.converse.return_value = mock_response

        client = BedrockAgentClient()
        messages = [{"role": "user", "content": [{"text": "Ping"}]}]
        thinking, reply, raw_res = client.converse_with_thinking(messages=messages, use_fast_model=True)

        self.assertIn("連線測試與狀態確認", thinking)
        self.assertEqual(reply, "系統已上線！『第五名』團隊您好。")
        self.assertEqual(raw_res["usage"]["totalTokens"], 130)
        print("✅ [Pass] PRO 級延伸思考引擎單元測試通過！")

if __name__ == '__main__':
    unittest.main()
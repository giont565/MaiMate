import unittest
from backend.agent.tools import AgentTools

class TestAgentTools(unittest.TestCase):
    """A 包階段 2 單元測試：Prepare / Execute 安全護欄與邊界測試"""

    def test_place_order_prepare_success(self):
        # 測試正常下單意圖，是否能正確產出 Confirm 卡片資料
        result = AgentTools.place_order_prepare(market="usdt_twd", side="buy", price=32.0, volume=100.0)
        self.assertEqual(result["status"], "REQUIRES_CONFIRMATION")
        self.assertEqual(result["estimated_cost"], 3200.0)
        print("✅ [Pass] Prepare 階段：正常下單意圖攔截與卡片生成成功！")
    
    def test_place_order_prepare_blocked(self):
        # 測試安全護欄：惡意或幻覺產生的超大金額應被無情攔截
        result = AgentTools.place_order_prepare(market="btc_twd", side="buy", price=2000000.0, volume=2.0)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertIn("上限", result["reason"])
        print("✅ [Pass] Prepare 階段：超過十萬台幣安全上限防護成功！")

    def test_place_order_execute_success(self):
        # 測試執行階段：簽章正確時放行
        result = AgentTools.place_order_execute(payload_hash="mock_hash_for_execute_888")
        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(result["order_id"], "MAX_ORD_123456789")
        print("✅ [Pass] Execute 階段：簽章驗證與模擬執行成功！")

if __name__ == '__main__':
    unittest.main()
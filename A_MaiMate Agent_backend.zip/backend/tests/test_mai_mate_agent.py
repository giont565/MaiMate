import unittest
from backend.agent.mai_mate_agent import MaiMateAgent

class TestMaiMateAgentFacade(unittest.TestCase):
    """A 包階段 4 單元測試：大腦總機組裝驗證"""

    def setUp(self):
        self.agent = MaiMateAgent()

    def test_analyze_and_propose(self):
        # 測試前端一鍵呼叫是否能同時拿到徽章與策略
        res = self.agent.analyze_user_and_propose_strategy(
            age=35, exp_years=6, risk="HIGH", budget=10000.0, price=32.0
        )
        
        # 驗證 Profile 引擎是否連動
        self.assertIn("👑 市場老手", res["user_profile"]["badges"])
        
        # 驗證計算機引擎是否連動
        self.assertEqual(res["strategy_cards"]["status"], "SUCCESS")
        self.assertEqual(len(res["strategy_cards"]["scenarios"]), 3)

    def test_trade_intent_routing(self):
        # 測試前端一鍵呼叫是否能正確觸發安全護欄
        res = self.agent.handle_trade_intent(market="usdt_twd", side="buy", price=32.0, volume=100.0)
        self.assertEqual(res["status"], "REQUIRES_CONFIRMATION")
        
        print("\n🏆 [大滿貫] 核心大腦組裝 (Facade) 測試完全通過！A 包全數完工準備交付！")

if __name__ == '__main__':
    unittest.main()
import unittest
from backend.agent.profile_engine import ProfileEngine
from backend.agent.strategy_calculator import StrategyCalculator

class TestEngines(unittest.TestCase):
    """A 包階段 3 單元測試：Profile 徽章與三方案計算"""

    def test_profile_engine(self):
        badges = ProfileEngine.generate_badges(age=35, investment_experience_years=6, risk_tolerance="HIGH")
        self.assertIn("👑 市場老手", badges)
        self.assertIn("🔥 積極進取", badges)
        print("✅ [Pass] Profile 引擎：徽章生成邏輯驗證成功！")

    def test_strategy_calculator(self):
        # 模擬 10,000 元台幣預算，市場幣價為 32.0
        result = StrategyCalculator.generate_three_plans(budget_twd=10000.0, current_market_price=32.0)
        
        self.assertEqual(result["status"], "SUCCESS")
        self.assertEqual(len(result["scenarios"]), 3)
        self.assertEqual(result["scenarios"][2]["plan_name"], "積極方案 (100%)")
        self.assertEqual(result["scenarios"][2]["estimated_cost"], 10000.0)
        print("✅ [Pass] 三方案計算機：Schema 輸出與金額試算完全正確！")

if __name__ == '__main__':
    unittest.main()